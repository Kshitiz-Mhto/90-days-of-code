package com.continering.letsee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LetseeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetseeApplication.class, args);
	}

}
